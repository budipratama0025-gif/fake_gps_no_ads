package id.cvtms.fakegpsbasic

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.location.Criteria
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var locationManager: LocationManager
    private lateinit var latitudeInput: EditText
    private lateinit var longitudeInput: EditText
    private lateinit var statusText: TextView
    private val handler = Handler(Looper.getMainLooper())
    private var running = false

    private val updateTask = object : Runnable {
        override fun run() {
            if (!running) return
            try {
                pushLocation()
                handler.postDelayed(this, 2000)
            } catch (e: Exception) {
                running = false
                statusText.text = "Gagal: " + (e.message ?: "izin lokasi tiruan belum aktif")
                Toast.makeText(this@MainActivity, statusText.text, Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 32, 24, 24)
        }
        root.addView(TextView(this).apply {
            text = "Fake GPS Basic"
            textSize = 26f
        }, matchWidth())
        root.addView(TextView(this).apply {
            text = "Untuk pengujian lokasi pada perangkat sendiri. Pilih aplikasi ini sebagai Mock Location App di Opsi Pengembang."
            textSize = 15f
            setPadding(0, 16, 0, 24)
        }, matchWidth())
        latitudeInput = EditText(this).apply {
            hint = "Latitude (contoh: -6.200000)"
            inputType = 8194
            setSingleLine(true)
        }
        root.addView(latitudeInput, matchWidth())
        longitudeInput = EditText(this).apply {
            hint = "Longitude (contoh: 106.816666)"
            inputType = 8194
            setSingleLine(true)
        }
        root.addView(longitudeInput, matchWidth())
        root.addView(Button(this).apply {
            text = "Mulai lokasi tiruan"
            setOnClickListener { startMockLocation() }
        }, matchWidth())
        root.addView(Button(this).apply {
            text = "Hentikan lokasi tiruan"
            setOnClickListener { stopMockLocation() }
        }, matchWidth())
        statusText = TextView(this).apply {
            text = "Status: belum aktif"
            textSize = 16f
            setPadding(0, 24, 0, 0)
        }
        root.addView(statusText, matchWidth())
        setContentView(root)
    }

    private fun matchWidth() =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    private fun startMockLocation() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 100)
            statusText.text = "Izinkan akses lokasi, lalu tekan Mulai lagi."
            return
        }
        try {
            val lat = latitudeInput.text.toString().toDouble()
            val lon = longitudeInput.text.toString().toDouble()
            require(lat in -90.0..90.0 && lon in -180.0..180.0) { "Koordinat di luar batas." }
            try {
                locationManager.addTestProvider(
                    LocationManager.GPS_PROVIDER,
                    false, false, false, false,
                    true, true, true,
                    Criteria.POWER_LOW, Criteria.ACCURACY_FINE
                )
            } catch (_: IllegalArgumentException) {
                // Provider already exists; reuse it.
            }
            locationManager.setTestProviderEnabled(LocationManager.GPS_PROVIDER, true)
            running = true
            pushLocation()
            handler.removeCallbacks(updateTask)
            handler.postDelayed(updateTask, 2000)
            statusText.text = "Lokasi tiruan aktif: $lat, $lon"
        } catch (e: Exception) {
            statusText.text = "Belum berhasil. Pastikan aplikasi dipilih di Opsi Pengembang. " + (e.message ?: "")
        }
    }

    private fun pushLocation() {
        val lat = latitudeInput.text.toString().toDouble()
        val lon = longitudeInput.text.toString().toDouble()
        val location = Location(LocationManager.GPS_PROVIDER).apply {
            latitude = lat
            longitude = lon
            accuracy = 3f
            time = System.currentTimeMillis()
            elapsedRealtimeNanos = SystemClock.elapsedRealtimeNanos()
            altitude = 0.0
            speed = 0f
            bearing = 0f
        }
        locationManager.setTestProviderLocation(LocationManager.GPS_PROVIDER, location)
    }

    private fun stopMockLocation() {
        running = false
        handler.removeCallbacks(updateTask)
        try {
            locationManager.setTestProviderEnabled(LocationManager.GPS_PROVIDER, false)
            locationManager.removeTestProvider(LocationManager.GPS_PROVIDER)
        } catch (_: Exception) {}
        if (::statusText.isInitialized) statusText.text = "Status: dihentikan"
    }

    override fun onDestroy() {
        stopMockLocation()
        super.onDestroy()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            statusText.text = "Izin lokasi diberikan. Tekan Mulai lokasi tiruan."
        } else {
            statusText.text = "Izin lokasi belum diberikan."
        }
    }
}
